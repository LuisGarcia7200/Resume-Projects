--
-- simple_company schema by CS 4347 Group 17
--

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

CREATE SCHEMA IF NOT EXISTS `simple_company` DEFAULT CHARACTER SET utf8 ;
USE `simple_company` ;

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `simple_company`.`customer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `gender` char(1) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(45) NOT NULL,
  `address` VARCHAR(45) NULL DEFAULT NULL,
  `creditcard` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `address`
--

CREATE TABLE IF NOT EXISTS `simple_company`.`address` (
  `address1` varchar(45) NOT NULL,
  `address2` varchar(45) DEFAULT NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `zipcode` varchar(45) NOT NULL,
  `CUSTOMER_id` int NOT NULL,
  CONSTRAINT `fk_ADDRESS_CUSTOMER` 
  FOREIGN KEY (`CUSTOMER_id`) 
  REFERENCES `simple_company`.`customer` (`id`) 
  ON DELETE CASCADE 
  ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `creditcard`
--

CREATE TABLE IF NOT EXISTS `simple_company`.`creditcard`(
  `CUSTOMER_id` int NOT NULL,
  `name` varchar(45) NOT NULL,
  `cc_number` varchar(45) NOT NULL,
  `exp_date` varchar(45) NOT NULL,
  `security_code` varchar(45) NOT NULL,
  INDEX `fk_CREDIT_CARD_CUSTOMER`(`CUSTOMER_id` ASC),
  CONSTRAINT `fk_CREDIT_CARD_CUSTOMER` 
  FOREIGN KEY (`CUSTOMER_id`) 
  REFERENCES `simple_company`.`customer` (`id`) 
  ON DELETE CASCADE 
  ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `simple_company`.`product`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `prod_name` varchar(45) NOT NULL,
  `prod_desc` varchar(1024) NOT NULL,
  `prod_category` int NOT NULL,
  `prod_upc` char(12) NOT NULL,
   PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `purchase`
--

CREATE TABLE IF NOT EXISTS `simple_company`.`purchase`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchase_date` varchar(45) NOT NULL,
  `purchase_amt` decimal(9,2) NOT NULL,
  `CUSTOMER_id` int NOT NULL,
  `PRODUCT_id` int NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_PURCHASE_CUSTOMER_idx` (`CUSTOMER_id` ASC),
  INDEX `fk_PURCHASE_PRODUCT_idx` (`PRODUCT_id` ASC),
  CONSTRAINT `fk_PURCHASE_CUSTOMER` 
  FOREIGN KEY (`CUSTOMER_id`) 
  REFERENCES `simple_company`.`customer` (`id`) 
  ON DELETE CASCADE 
  ON UPDATE CASCADE,
  CONSTRAINT `fk_PURCHASE_PRODUCT` 
  FOREIGN KEY (`PRODUCT_id`)
  REFERENCES `simple_company`.`product` (`id`) 
  ON DELETE CASCADE
  ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
