/* NOTICE: All materials provided by this project, and materials derived 
 * from the project, are the property of the University of Texas. 
 * Project materials, or those derived from the materials, cannot be placed 
 * into publicly accessible locations on the web. Project materials cannot 
 * be shared with other project teams. Making project materials publicly 
 * accessible, or sharing with other project teams will result in the 
 * failure of the team responsible and any team that uses the shared materials. 
 * Sharing project materials or using shared materials will also result 
 * in the reporting of every team member to the Provost Office for academic 
 * dishonesty. 
 */ 

package cs4347.jdbcProject.ecomm.services.impl;

import java.sql.SQLException;
import java.util.List;
import java.sql.Connection;
import javax.sql.DataSource;

import cs4347.jdbcProject.ecomm.entity.Product;
import cs4347.jdbcProject.ecomm.services.ProductPersistenceService;
import cs4347.jdbcProject.ecomm.util.DAOException;
import cs4347.jdbcProject.ecomm.dao.ProductDAO;
import cs4347.jdbcProject.ecomm.dao.impl.ProductDaoImpl;

/*
 * ProductPersistenceService Implementation
 * NAME: Eric Ikeda
 * CLASS: CS 4347.002
 * NETID: eai170000
 * GROUP: 17
 * DATE: 4/4/2021
 */

public class ProductPersistenceServiceImpl implements ProductPersistenceService
{
	
	@Override
	//Create Product Object.
	//Call create Product method.
    public Product create(Product product) throws SQLException, DAOException
    {
		//If the Product ID is not null, throw a DAO exception as per the requirements listed in ProductPersistenceService.java
		if(product.getId() != null) {
			DAOException notNull = new DAOException("Given product with ID " + product.getId() + " Should be null");
			throw notNull;
		}
		ProductDAO productDAO = new ProductDaoImpl();
		Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 Product prod = productDAO.create(connection, product);
			 connection.commit();
			 return prod;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
    }

    @Override
    //Create Product Object.
    //Call the retrieve Product method.
    public Product retrieve(Long id) throws SQLException, DAOException
    {
    	//If the ID given is null, throw a DAO exception as per the requirements listed in ProductPersistenceService.java
    	if(id == null) {
    		DAOException nullId = new DAOException("Given product with NULL ID");
    		throw nullId;
    	}
    	ProductDAO productDAO = new ProductDaoImpl();
		Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 Product prod = productDAO.retrieve(connection,id);
			 connection.commit();
			 return prod;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
    }

    @Override
    //Create Product Object.
    //Call the update Product method.
    public int update(Product product) throws SQLException, DAOException
    {
    	//If the Product ID is null, throw a DAO exception as per the requirements listed in ProductPersistenceService.java
    	if(product.getId() == null) {
    		DAOException NullId = new DAOException("Error. Asked to update product with NULL ID");
    		throw NullId;
    	}
    	ProductDAO productDAO = new ProductDaoImpl();
		Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 int prod = productDAO.update(connection,product);
			 connection.commit();
			 return prod;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
    }

    @Override
    //Create Product Object.
    //Call the delete Product method.
    public int delete(Long id) throws SQLException, DAOException
    {
    	//If the Product ID is null, throw a DAO exception as per the requirements listed in ProductPersistenceService.java
    	if(id == null) {
    		DAOException NullId = new DAOException("Asked to delete product with a NULL ID given");
    		throw NullId;
    	}
    	ProductDAO productDAO = new ProductDaoImpl();
		Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 int prod = productDAO.delete(connection,id);
			 connection.commit();
			 return prod;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
    }

    @Override
    //Create Product Object.
    //Call the retrieve Product by its UPC method.
    public Product retrieveByUPC(String upc) throws SQLException, DAOException
    {
    	ProductDaoImpl productDAO = new ProductDaoImpl();
		Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 Product prod = productDAO.retrieveByUPC(connection, upc);
			 connection.commit(); 
			 return prod;
			 
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
		
    	
    	
    }

    @Override
    //Create Product Object.
    //Call the retrieve Product by Category method.
    public List<Product> retrieveByCategory(int category) throws SQLException, DAOException
    {
    	ProductDAO productDAO = new ProductDaoImpl();
		Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 List<Product> prodList = productDAO.retrieveByCategory(connection, category);
			 connection.commit();
			 return prodList;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
    }

    private DataSource dataSource;

	public ProductPersistenceServiceImpl(DataSource dataSource)
	{
		this.dataSource = dataSource;
	}

}
