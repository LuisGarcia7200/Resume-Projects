/* NOTICE: All materials provided by this project, and materials derived 
 * from the project, are the property of the University of Texas. 
 * Project materials, or those derived from the materials, cannot be placed 
 * into publicly accessible locations on the web. Project materials cannot 
 * be shared with other project teams. Making project materials publicly 
 * accessible, or sharing with other project teams will result in the 
 * failure of the team responsible and any team that uses the shared materials. 
 * Sharing project materials or using shared materials will also result 
 * in the reporting of every team member to the Provost Office for academic 
 * dishonesty. 
 */ 



package cs4347.jdbcProject.ecomm.dao.impl;

import java.sql.Connection;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cs4347.jdbcProject.ecomm.dao.CustomerDAO;
import cs4347.jdbcProject.ecomm.entity.Customer;
import cs4347.jdbcProject.ecomm.util.DAOException;

/*
* CustomerDAO Implementation
* NAME: Toan Nguyen
* CLASS: CS 4347.002
* NETID: tdn160330
* GROUP: 17
* DATE: 4/4/2021
*/

public class CustomerDaoImpl implements CustomerDAO
{
  
	 private static final String insertSQL = "INSERT INTO customer (id, first_name, last_name, gender, dob, email) VALUES (?, ?, ?, ?, ?, ?);";

	 private static final String deleteSQL = "DELETE FROM CUSTOMER WHERE id = ?;";

	 private static final String updateSQL = "UPDATE customer SET first_name = ?, last_name = ?, gender = ?, dob = ?, email = ? WHERE id = ?;";

	 private static final String selectSQL =  "SELECT id, first_name, last_name, gender, dob, email FROM customer where id = ?"; 

	 private static final String selectByZipSQL = "SELECT id, first_name, last_name, gender, dob, email FROM customer,address where customer.id = address.CUSTOMER_ID and address.zipcode = ?"; 

	 private static final String selectByDobSQL = "SELECT id, first_name, last_name, gender, dob, email FROM customer WHERE dob between ? AND ?"; 
	    
    @Override
    //Create a Customer Object associated with the inputed Customer. 
    //Throw DAOException when given a NON-NULL Customer ID. 
    //Returns Customer with the ID attribute assigned the key value provided by the auto-increment primary key column.
    public Customer create(Connection connection, Customer customer) throws SQLException, DAOException
    {
        //Throw DAOEException when given a Customer with a NON-NULL ID attribute.
    	if (customer.getId() != null)
		{
			throw new DAOException("Error. Trying to insert customer with a NON-NULL ID");
		}
		PreparedStatement ps = null;
		try
		{
			ps = connection.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS);
			ps.setLong(1, 0); //Set placeholder for auto-increment key.
			ps.setString(2, customer.getFirstName());
			ps.setString(3, customer.getLastName());
			ps.setString(4, Character.toString(customer.getGender()));
			ps.setDate(5, customer.getDob());
			ps.setString(6, customer.getEmail());
			ps.executeUpdate();
			
			//Copy the SQL generated auto-increment key to the Customer ID.
			ResultSet keyRS = ps.getGeneratedKeys();
			//set ID to the correct ID.
			if(keyRS.next())
			{
				int lastKey = keyRS.getInt(1);
				customer.setId((long) lastKey);
			}
			else
			{
				throw new SQLException("Error. Could not generate auto-increment key");
			}
			return customer;
		}
		finally
		{
			if (ps != null && !ps.isClosed())
			{
				ps.close();
			}
		}
    	
    }

    @Override
    //Retrieve a Customer Object associated with the inputed ID.
    //Throw DAOException when given a NULL Customer ID.
    //Return null if retrieving a non-existent ID.
    public Customer retrieve(Connection connection, Long id) throws SQLException, DAOException
    {
    	//Throw DAOException when given a NULL Customer ID.
    	if (id == null) {
    		throw new DAOException("Error. Trying to retrieve Customer with NULL Customer ID");
        }

        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(selectSQL);
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            //Return null if retrieving a non-existent ID.
            if (!rs.next()) {
                return null;
            }

            Customer customer = new Customer();
            customer.setId(rs.getLong("id"));
            customer.setFirstName(rs.getString("first_name"));
            customer.setLastName(rs.getString("last_name"));
            customer.setGender(rs.getString("gender").charAt(0));
            customer.setDob(rs.getDate("dob"));
            customer.setEmail(rs.getString("email"));
            return customer;
        }
        finally {
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
        }
    }

    @Override
    //Update the inputed Customer Object.
	//Throw DAOException when given a Customer Object with a NULL Customer ID.
    public int update(Connection connection, Customer customer) throws SQLException, DAOException
    {
    	//Throw DAOException when given a Customer Object with a NULL Customer ID.
    	if (customer.getId() == null) {
            throw new DAOException("Error. Trying to update Customer with NULL Customer ID");
        }

        PreparedStatement ps = null;
        try{
            ps = connection.prepareStatement(updateSQL);
            ps.setString(1, customer.getFirstName());
            ps.setString(2, customer.getLastName());
            ps.setString(3, String.valueOf(customer.getGender()));
            ps.setDate(4,customer.getDob());
            ps.setString(5, customer.getEmail());
            ps.setLong(6, customer.getId());
            int rows = ps.executeUpdate();
            return rows;
        }
        finally {
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
        }
    	
    }

    @Override
    //Delete a Customer Object associated with the inputed Customer ID.
    //Throw DAOException when given a NULL Customer ID.
    public int delete(Connection connection, Long id) throws SQLException, DAOException
    {
    	 //Throw DAOException when given a NULL Customer ID.
    	if (id == null) {
            throw new DAOException("Error. Trying to delete Customer with NULL Customer ID");
        }

        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(deleteSQL);
            ps.setLong(1, id);
            int rows = ps.executeUpdate();
            return rows;
        }
        finally {
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
        }
    }

    @Override
    //Retrieve a List of Customer Objects associated with the inputed ZipCode.
    //Throw DAOException if given a NULL ZipCode.
    public List<Customer> retrieveByZipCode(Connection connection, String zipCode) throws SQLException, DAOException
    {
    	//Throw DAOException when given a NULL ZipCode.
    	if(zipCode == null) {
    		  throw new DAOException("Error. Trying to retrieve Customers with NULL ZipCode");
    	}
    	
    	PreparedStatement ps = null;
        try{
            ps = connection.prepareStatement(selectByZipSQL);
            ps.setString(1, zipCode);
            ResultSet rs = ps.executeQuery();
            List<Customer> result = new ArrayList<Customer>();
            
            while(rs.next()) {
                Customer customer = new Customer();
                customer.setId(rs.getLong("id"));
                customer.setFirstName(rs.getString("first_name"));
                customer.setLastName(rs.getString("last_name"));
                customer.setGender(rs.getString("gender").charAt(0));
                customer.setDob(rs.getDate("dob"));
                customer.setEmail(rs.getString("email"));
                result.add(customer);
            }
           
            
            return result;

        }
        finally {
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
        }
    	
    	
    }

    @Override
    //Retrieve a List of Customer Objects in between the two inputed DOB.
    //Throw DAOException if given a null startDate or endDate.
    public List<Customer> retrieveByDOB(Connection connection, Date startDate, Date endDate) throws SQLException, DAOException
    {
    	 //Throw DAOException when given a NULL startDate or endDate.
    	if(startDate == null || endDate == null) {
    		 throw new DAOException("Error. Trying to retrieve Customers with NULL startDate or endDate");
    	}
    	
    	PreparedStatement ps = null;
        try{
            ps = connection.prepareStatement(selectByDobSQL);
            ps.setDate(1, startDate);
            ps.setDate(2, endDate);
            ResultSet rs = ps.executeQuery();
            List<Customer> result = new ArrayList<Customer>();
            
            while(rs.next()) {
                Customer customer = new Customer();
                customer.setId(rs.getLong("id"));
                customer.setFirstName(rs.getString("first_name"));
                customer.setLastName(rs.getString("last_name"));
                customer.setGender(rs.getString("gender").charAt(0));
                customer.setDob(rs.getDate("dob"));
                customer.setEmail(rs.getString("email"));
                result.add(customer);
            }
          
            
            return result;
        } 
        finally {
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
        }
    	
    }
	
}

