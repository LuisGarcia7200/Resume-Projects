/* NOTICE: All materials provided by this project, and materials derived 
 * from the project, are the property of the University of Texas. 
 * Project materials, or those derived from the materials, cannot be placed 
 * into publicly accessible locations on the web. Project materials cannot 
 * be shared with other project teams. Making project materials publicly 
 * accessible, or sharing with other project teams will result in the 
 * failure of the team responsible and any team that uses the shared materials. 
 * Sharing project materials or using shared materials will also result 
 * in the reporting of every team member to the Provost Office for academic 
 * dishonesty. 
 */ 


package cs4347.jdbcProject.ecomm.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cs4347.jdbcProject.ecomm.dao.PurchaseDAO;
import cs4347.jdbcProject.ecomm.entity.Purchase;
import cs4347.jdbcProject.ecomm.services.PurchaseSummary;
import cs4347.jdbcProject.ecomm.util.DAOException;

/*
 * PurchaseDAO Implementation
 * NAME: Luis Garcia
 * CLASS: CS 4347.002
 * NETID: lag170530
 * GROUP: 17
 * DATE: 4/4/2021
 */

public class PurchaseDaoImpl implements PurchaseDAO
{
    
    private static final String insertSQL = "INSERT INTO purchase (CUSTOMER_id, PRODUCT_id, purchase_date, purchase_amt) VALUES(?, ?, ?, ?);";
    
    private static final String selectSQL = "SELECT id, CUSTOMER_id, PRODUCT_id, purchase_date, purchase_amt FROM purchase WHERE id = ?;";
    
    private static final String updateSQL = "UPDATE purchase SET CUSTOMER_id = ?, PRODUCT_id = ?, purchase_date = ?, purchase_amt = ? WHERE id = ?;";
    
    private static final String deleteSQL = "DELETE FROM purchase WHERE id = ?;";
    
    private static final String selectByCustIDSQL = "SELECT id, CUSTOMER_id, PRODUCT_id, purchase_date, purchase_amt FROM purchase WHERE CUSTOMER_id = ?;";
    
    private static final String selectBYProdIDSQL = "SELECT id, CUSTOMER_id, PRODUCT_id, purchase_date, purchase_amt FROM purchase WHERE PRODUCT_ID = ?;";
    
    private static final String selectAGGSQL = "SELECT MIN(purchase_amt) AS 'purchase_min', MAX(purchase_amt) AS 'purchase_max', AVG(purchase_amt) AS 'purchase_avg' FROM purchase WHERE CUSTOMER_id = ?;";
    
    @Override
    //Create a Purchase Object associated with the inputed Purchase. 
    //Throw DAOException when given a NON-NULL Purchase id. 
    //Returns Purchase with the ID attribute assigned the key value provided by the auto-increment primary key column.
    public Purchase create(Connection connection, Purchase purchase) throws SQLException, DAOException
    { 
    	//Throw DAOException when given a NON-NULL Purchase id. 
    	if(purchase.getId() != null) {
    		throw new DAOException("Error. Trying to insert Purchase with NON-NULL ID");
    	}
    	
    	PreparedStatement ps = null;
    	try {
    		ps = connection.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS);
    		ps.setLong(1, purchase.getCustomerID());
    		ps.setLong(2, purchase.getProductID());
    		ps.setDate(3, purchase.getPurchaseDate());
    		ps.setDouble(4, purchase.getPurchaseAmount());
    		ps.executeUpdate();
    		
    		//Copy the SQL generated auto-increment key to the Purchase ID.
			ResultSet keyRS = ps.getGeneratedKeys();
			//set ID to the correct ID.
			if(keyRS.next())
			{
				int lastKey = keyRS.getInt(1);
				purchase.setId((long) lastKey);
			}
			else
			{
				throw new SQLException("Error. Could not generate auto-increment key.");
			}
    		return purchase;
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
    	
    	
    	
       
    }

    @Override
    //Retrieve a Purchase Object associated with the inputed Purchase ID.
    //Throw DAOException if given a NULL Purchase ID.
    //Return NULL if retrieving a non-existent Purchase ID.
    public Purchase retrieve(Connection connection, Long id) throws SQLException, DAOException
    { 
    	//Throw DAOException if given a NULL Purchase ID.
        if(id == null) {
        	throw new DAOException("Error. Trying to retrieve Purchase with NULL ID");
        }
        
        PreparedStatement ps = null;
        try {
        	ps = connection.prepareStatement(selectSQL);
        	ps.setLong(1, id);
        	ResultSet rs = ps.executeQuery();
        	 //Return NULL if retrieving a non-existent Purchase ID.
        	if(!rs.next()) {
        		return null;
        	}
        	Purchase purc = new Purchase();
        	purc.setId(rs.getLong("id"));
        	purc.setCustomerID(rs.getLong("CUSTOMER_ID"));
        	purc.setProductID(rs.getLong("PRODUCT_ID"));
        	purc.setPurchaseDate(rs.getDate("purchase_date"));
        	purc.setPurchaseAmount(rs.getDouble("purchase_amt"));
        	return purc;
        }
        finally {
        	if(ps != null && !ps.isClosed()) {
        		ps.close();
        	}
        }
        
    }

    @Override
    //Update the inputed Purchase Object.
  	//Throw DAOException when given a Product Object with a NULL Purchase ID.
    public int update(Connection connection, Purchase purchase) throws SQLException, DAOException
    { 
       if(purchase.getId() == null) {
    	   throw new DAOException("Error. Trying to update Purchase with NULL Purchase ID");
       }
       
       PreparedStatement ps = null;
       try {
    	   ps = connection.prepareStatement(updateSQL);
   		   ps.setLong(1, purchase.getCustomerID());
   		   ps.setLong(2, purchase.getProductID());
   		   ps.setDate(3, purchase.getPurchaseDate());
   		   ps.setDouble(4, purchase.getPurchaseAmount());
   		   ps.setLong(5, purchase.getId());
   		   int rows = ps.executeUpdate();
   		   return rows;
       }
       finally {
    	   if(ps != null && !ps.isClosed()) {
    		  ps.close(); 
    	   }
       }
       
        
    }

    @Override
    //Delete a Product Object associated with the inputed Product ID.
    //Throw DAOException when given a NULL Product ID.
    public int delete(Connection connection, Long id) throws SQLException, DAOException
    {
    	 //Throw DAOException when given a NULL Purchase ID.
    	if(id == null) {
    		throw new DAOException("Error. Trying to delete Purchase with NULL Purchase ID.");
    	}
    	PreparedStatement ps = null;
    	try {
    		ps = connection.prepareCall(deleteSQL);
    		ps.setLong(1,id);
    		int rows = ps.executeUpdate();
    		return rows;
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
        
    }

    @Override
    //Retrieve a List of Purchase Objects associated with the inputed Customer ID.
    //Throw DAOException if given a NULL Customer ID.
    public List<Purchase> retrieveForCustomerID(Connection connection, Long customerID) throws SQLException, DAOException
    { 
    	//Throw DAOException if given a NULL Customer ID.
    	if (customerID == null) {
            throw new DAOException("Error. Trying to retrieve Purchase with NULL Customer ID");
        }
    	
    	PreparedStatement ps = null;
    	try{
    		ps = connection.prepareStatement(selectByCustIDSQL);
    		ps.setLong(1, customerID);
    		ResultSet rs = ps.executeQuery();
    		List<Purchase> result = new ArrayList<Purchase>();
    		while(rs.next()) {
    			Purchase purc = new Purchase();
            	purc.setId(rs.getLong("id"));
            	purc.setCustomerID(rs.getLong("CUSTOMER_ID"));
            	purc.setProductID(rs.getLong("PRODUCT_ID"));
            	purc.setPurchaseDate(rs.getDate("purchase_date"));
            	purc.setPurchaseAmount(rs.getDouble("purchase_amt"));
            	result.add(purc);
    		}
    		
    		
            
    		 return result;
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
       
    }

    @Override
    //Retrieve a List of Purchase Objects associated with the inputed Product ID.
    //Throw DAOException if given a NULL Product ID.
    public List<Purchase> retrieveForProductID(Connection connection, Long productID) throws SQLException, DAOException
    { 
    	//Throw DAOException if given a NULL Product ID.
    	if (productID == null) {
            throw new DAOException("Error. Trying to retrieve Purchase with NULL Product ID");
        }
    	
    	PreparedStatement ps = null;
    	try{
    		ps = connection.prepareStatement(selectBYProdIDSQL);
    		ps.setLong(1, productID);
    		ResultSet rs = ps.executeQuery();
    		List<Purchase> result = new ArrayList<Purchase>();
    		while(rs.next()) {
    			Purchase purc = new Purchase();
            	purc.setId(rs.getLong("id"));
            	purc.setCustomerID(rs.getLong("CUSTOMER_ID"));
            	purc.setProductID(rs.getLong("PRODUCT_ID"));
            	purc.setPurchaseDate(rs.getDate("purchase_date"));
            	purc.setPurchaseAmount(rs.getDouble("purchase_amt"));
            	result.add(purc);
    		}
            
    		return result;
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
    }

    @Override
    //Retrieve PurchaseSummary of the given Customer ID.
    //Requires use of Three SQL Aggregate Functions within a SELECT of the customerID.
    //Throw DAOException if customerID is null
    public PurchaseSummary retrievePurchaseSummary(Connection connection, Long customerID) throws SQLException, DAOException
    { 
    	//Throw DAOException if given a NULL Customer ID.
    	if (customerID == null) {
            throw new DAOException("Error. Trying to retrieve PurchaseSummary with NULL Customer ID");
        }
    	
    	float minPurc = 0;
    	float maxPurc = 0;
    	float avgPurc = 0;
    	PreparedStatement ps = null;
    	try {
    		ps = connection.prepareStatement(selectAGGSQL);
    		ps.setLong(1, customerID);
    		ResultSet rs = ps.executeQuery();
    		while(rs.next()) {
    			minPurc = (float) rs.getDouble("purchase_min");   
    			maxPurc = (float) rs.getDouble("purchase_max");
    			avgPurc = (float) rs.getDouble("purchase_avg");
    		}
    		PurchaseSummary sum = new PurchaseSummary();
    		sum.minPurchase = minPurc;
    		sum.maxPurchase = maxPurc;
    		sum.avgPurchase = avgPurc;
    		return sum;
    	
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
    	
    	
    }
	
}
