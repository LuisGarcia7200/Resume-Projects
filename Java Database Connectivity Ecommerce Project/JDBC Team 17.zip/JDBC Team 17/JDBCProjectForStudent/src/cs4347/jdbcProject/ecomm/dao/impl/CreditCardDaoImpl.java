/* NOTICE: All materials provided by this project, and materials derived 
 * from the project, are the property of the University of Texas. 
 * Project materials, or those derived from the materials, cannot be placed 
 * into publicly accessible locations on the web. Project materials cannot 
 * be shared with other project teams. Making project materials publicly 
 * accessible, or sharing with other project teams will result in the 
 * failure of the team responsible and any team that uses the shared materials. 
 * Sharing project materials or using shared materials will also result 
 * in the reporting of every team member to the Provost Office for academic 
 * dishonesty. 
 */ 



package cs4347.jdbcProject.ecomm.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import cs4347.jdbcProject.ecomm.dao.CreditCardDAO;
import cs4347.jdbcProject.ecomm.entity.CreditCard;
import cs4347.jdbcProject.ecomm.util.DAOException;

/*
 * CreditCard Implementation
 * NAME: Zachary Gray
 * CLASS: CS 4347.002
 * NETID: zsg170000
 * GROUP: 17
 * DATE: 4/4/2021
 */

public class CreditCardDaoImpl implements CreditCardDAO
{
	
	private static final String insertSQL = "INSERT INTO creditcard (CUSTOMER_id, name, cc_number, exp_date, security_code) VALUES(?, ?, ?, ?, ?);";
		    
	private static final String selectSQL = "SELECT CUSTOMER_id, name, cc_number, exp_date, security_code FROM creditcard "+ "WHERE CUSTOMER_id = ?";
	
	private static final String deleteSQL = "DELETE FROM creditcard WHERE CUSTOMER_id = ?;";
	
    @Override
    //Create a Credit Card Object associated with the inputed Customer ID. 
    //Throw DAOException when given a NULL Customer ID. 
    public CreditCard create(Connection connection, CreditCard creditCard, Long customerID) throws SQLException, DAOException
    {
    	//Throw DAOException when given a NULL Customer ID.
    	if(customerID == null) {
    		throw new DAOException("Error. Trying to insert Credit Card with NULL ID");
    	}
    	
    	PreparedStatement ps = null;
    	try {
    		ps = connection.prepareStatement(insertSQL);
    		ps.setLong(1, customerID);
    		ps.setString(2, creditCard.getName());
    		ps.setString(3, creditCard.getCcNumber());
    		ps.setString(4, creditCard.getExpDate());
    		ps.setString(5, creditCard.getSecurityCode());
    		int res = ps.executeUpdate();
    		if(res != 1) {
    			throw new DAOException("Error. Create did not execute the correct amount of rows.");
    		}
    		
    		return creditCard;
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
    }

    @Override
    //Retrieve a Credit Card Object associated with the inputed Customer ID.
    //Throw DAOException when given a NULL CustomerID.
    //Return null if retrieving a non-existent Customer ID.
    public CreditCard retrieveForCustomerID(Connection connection, Long customerID) throws SQLException, DAOException
    {
    	//Throw DAOException when given a NULL CustomerID.
    	if(customerID == null){
    		throw new DAOException("Error. Trying to retrieve Credit Card with NULL ID");
		}
    	
    	PreparedStatement ps = null;
    	try{
    		ps = connection.prepareStatement(selectSQL);
    		ps.setLong(1, customerID);
    		ResultSet rs = ps.executeQuery();
    		//Return NULL if retrieving a non-existent Customer ID.
    		if(!rs.next()) {
    			return null;
    		}
    		
    		CreditCard creditCard = new CreditCard();
    		creditCard.setName(rs.getString("name"));
    		creditCard.setCcNumber(rs.getString("cc_number"));
    		creditCard.setExpDate(rs.getString("exp_date"));
            creditCard.setSecurityCode(rs.getString("security_code"));
    		return creditCard;
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
    }

    @Override
    //Delete a Credit Card Object associated with the inputed Customer ID.
    //Throw a DAOException when given a NULL Customer ID.
    public void deleteForCustomerID(Connection connection, Long customerID) throws SQLException, DAOException
    {
    	//Throw DAOException when given a NULL Customer ID.
    	if(customerID == null) {
    		throw new DAOException("Error. Trying to delete Credit Card with NULL ID.");
    	}
    	PreparedStatement ps = null;
    	try {
    		ps = connection.prepareCall(deleteSQL);
    		ps.setLong(1, customerID);
    		ps.execute();
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
        
    }

}
