/* NOTICE: All materials provided by this project, and materials derived 
 * from the project, are the property of the University of Texas. 
 * Project materials, or those derived from the materials, cannot be placed 
 * into publicly accessible locations on the web. Project materials cannot 
 * be shared with other project teams. Making project materials publicly 
 * accessible, or sharing with other project teams will result in the 
 * failure of the team responsible and any team that uses the shared materials. 
 * Sharing project materials or using shared materials will also result 
 * in the reporting of every team member to the Provost Office for academic 
 * dishonesty. 
 */ 

package cs4347.jdbcProject.ecomm.services.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;


import cs4347.jdbcProject.ecomm.dao.PurchaseDAO;
import cs4347.jdbcProject.ecomm.dao.impl.PurchaseDaoImpl;
import cs4347.jdbcProject.ecomm.entity.Purchase;
import cs4347.jdbcProject.ecomm.services.PurchasePersistenceService;
import cs4347.jdbcProject.ecomm.services.PurchaseSummary;
import cs4347.jdbcProject.ecomm.util.DAOException;

/*
 * PurchasePersistenceService Implementation
 * NAME: Luis Garcia
 * CLASS: CS 4347.002
 * NETID: lag170530
 * GROUP: 17
 * DATE: 4/4/2021
 */

public class PurchasePersistenceServiceImpl implements PurchasePersistenceService
{
	private DataSource dataSource;

	public PurchasePersistenceServiceImpl(DataSource dataSource)
	{
		this.dataSource = dataSource;
	}
	
	@Override
	//Create Purchase Object.
    //Call the create Purchase method.
    public Purchase create(Purchase purchase) throws SQLException, DAOException
    {
		PurchaseDaoImpl purchaseDAO = new PurchaseDaoImpl();
		Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 Purchase purc = purchaseDAO.create(connection, purchase);
			 connection.commit();
			 return purc;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
       
    }

    @Override
    //Create Purchase Object.
    //Call the retrieve Purchase method.
    public Purchase retrieve(Long id) throws SQLException, DAOException
    {
        PurchaseDaoImpl purchaseDAO = new PurchaseDaoImpl();
		Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 Purchase purc = purchaseDAO.retrieve(connection,id);
			 connection.commit();
			 return purc;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
    }

    @Override
    //Create Purchase Object.
    //Call the update Purchase method.
    public int update(Purchase purchase) throws SQLException, DAOException
    {
		PurchaseDAO purchaseDAO = new PurchaseDaoImpl();
    	Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 int purc = purchaseDAO.update(connection,purchase);
			 connection.commit();
			 return purc;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
        
    }

    @Override
    //Create Purchase Object.
    //Call the delete Purchase method.
    public int delete(Long id) throws SQLException, DAOException
    {
        PurchaseDAO purchaseDAO = new PurchaseDaoImpl();
    	Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 int purc = purchaseDAO.delete(connection,id);
			 connection.commit();
			 return purc;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
        
    }

    @Override
    //Create Purchase Object.
    //Call the retrieve Purchase by Customer ID method.
    public List<Purchase> retrieveForCustomerID(Long customerID) throws SQLException, DAOException
    {
    	
        PurchaseDAO purchaseDAO = new PurchaseDaoImpl();
    	Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 List<Purchase> purc = purchaseDAO.retrieveForCustomerID(connection, customerID);
			 connection.commit();
			 return purc;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
        
    }

    @Override
    //Create Purchase Object.
    //Call the retrieve Purchase Sumamry method.
    public PurchaseSummary retrievePurchaseSummary(Long customerID) throws SQLException, DAOException
    {
    	
        PurchaseDAO purchaseDAO = new PurchaseDaoImpl();
    	Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 PurchaseSummary purc = purchaseDAO.retrievePurchaseSummary(connection, customerID);
			 connection.commit();
			 return purc;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
    }

    @Override
    //Create Purchase Object.
    //Call the retrieve Purchase by Product ID method.
    public List<Purchase> retrieveForProductID(Long productID) throws SQLException, DAOException
    {
        PurchaseDAO purchaseDAO = new PurchaseDaoImpl();
    	Connection connection = dataSource.getConnection();
		try {
			 connection.setAutoCommit(false);
			 List<Purchase> purc = purchaseDAO.retrieveForProductID(connection, productID);
			 connection.commit();
			 return purc;
		}
		catch (Exception ex) {
            connection.rollback();
            throw ex;
        }
        finally {
            if (connection != null) {
                connection.setAutoCommit(true);
            }
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        }
    }

    

}
