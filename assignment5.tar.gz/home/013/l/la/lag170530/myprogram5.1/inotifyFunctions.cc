/*
 * Filename: inotifyFunctions.cc
 * Date: 11/16/2020
 * Author: Luis Garcia
 * Email: lag170530@utdallas.edu
 * Course CS 3377.002 Fall 2020
 * Version 1.0 (or correct version)
 * Copyright 2020, All Rights Reserved
 *
 * Description
 *
 * The inotifyFunctions.cc has 3 methods in this that primarily deals with phase 5 and 6 tasks. The first method is the void inotifyFunction() that will watch and log any 
 * events dealing with modified files located in the watchdir (found in conf file). It will utilize the read command so it is CPU efficient because it will be run in an 
 * infinite loop in program5.cc. The void getTimeStamp() will utilize the popen and date commands to be able to make a timestamp of the format: year.month.date-hour.minute.seconds.
 * The void createCopy will utilize the popen and cp commands in order to create a copy of the modified file, save a copy as filename plus timestamp, and save that in the folder .versions
 * that is a subfolder located in the watchdir.
 */


#include "program5.h"

using namespace std;

//Contiously watching the watchdir listed in conf file. When it finds a IN_MODIFY, copy of the file and save it to .versions.
//Will log when a change occurs and when a copy is created.
//Steps: init(), add a watch, read command for IN_MODIFY, and rm watch at end.
void inotifyFunction(){
  int initVar = 0;
  int watchVar = 9;
  int count = 0;
  int i = 0;
  string fileName;
  size_t bufsize = sizeof(struct inotify_event) + PATH_MAX + 1;
  struct inotify_event *event = (struct inotify_event*)malloc(bufsize);

  initVar = inotify_init();

  if(initVar < 0){
    cerr << "inotify_init() error" << endl;

  }

  const char* watchDir = queryMap[WATCH_DIR].c_str();
  watchVar = inotify_add_watch(initVar, watchDir, IN_MODIFY);

  loginotify();
  count = read(initVar, event, bufsize);

  if(count < 0){
    perror("read error");
  }

  while(i < count){

    if(event->mask & IN_MODIFY){
      string verboseVal = queryMap[VERBOSE];
      fileName = event->name;
      if(verboseVal.compare("true") == 0 || verboseVal.compare("True") == 0 || verboseVal.compare("TRUE") == 0){
        logFileChangeVerbose(fileName);
      }
      else{
        logFileChange();
      }
      createCopy(fileName);
    }
    i += (sizeof(struct inotify_event) + event->len);
  }

  inotify_rm_watch(initVar, watchVar);

  close(initVar);



}

//Used for the date format of .Y.M.D.-HH:MM:SS to be appended on filenames.
//Uses popen and the date command to get the timestamp format
string getTimeStamp(){
  FILE *DateString;
  string shellCmd1 = "date +\".%Y.%m.%d-%T\"";
  char *call1;
  char tempBuffer1[1024];
  DateString = popen(shellCmd1.c_str(), "r");
  if(!DateString){
    return "error";
  }
  call1 = fgets(tempBuffer1, 1024, DateString);
  pclose(DateString);
  string str = string(call1);
  return str;
}

//Used to create copies of modified files with a timestamp appended to filename.
//Uses popen and the cp command to copy the file into the .versions directory 
void createCopy(string fileName){
  string copyName = fileName;
  string date = getTimeStamp();
  copyName.append(date);

  string pathName = "/home/013/l/la/lag170530/testdir/";  
  string pathNameV = "/home/013/l/la/lag170530/testdir/.versions/";

  FILE *copyFile;
  string shellCmd2 = "cp " + pathName + fileName + " " + pathNameV + copyName;
  copyFile = popen(shellCmd2.c_str(), "r");
  if(!copyFile){
    perror("error");
  }
  pclose(copyFile);
  string verboseVal2 = queryMap[VERBOSE];
  if(verboseVal2.compare("true") == 0 || verboseVal2.compare("True") == 0 || verboseVal2.compare("TRUE") == 0){
    logFileCopyVerbose(copyName);
  }
  else{
    logFileCopy();
  }

  
}

