/*
 * Filename: signalHandling.cc
 * Date: 11/16/2020
 * Author: Luis Garcia
 * Email: lag170530@utdallas.edu
 * Course CS 3377.002 Fall 2020
 * Version 1.0 (or correct version)
 * Copyright 2020, All Rights Reserved
 *
 * Description
 *
 * This file has three methods that will be used to catch three signals of SIGINT, SIGTERM, and SIGHUP. Getting the signals of 
 * SIGINT and SIGTERM will terminate the program. Getting the signal of SIGHUP will cause the program to reread the config file
 * and reconfigure the program to match the settings of the new config file except the password and watchdir values. 
 */


#include "program5.h"

using namespace std;

//Handles SIGINT signal. Terminates program.
void signalHandling1(int signum){
  logSIGINT(signum);
  exitProgram();
  exit(signum);
}
 
//Handles SIGTERM signal. Terminates program.
void signalHandling2(int signum){
  logSIGTERM(signum);
  exitProgram();
  exit(signum);
}


//Handles SIGHUP signal. Reread config file and reconfigure settings to new file.
  void signalHandling3(int signum){
  logSIGHUP(signum);
  //Keep the password and watchDir from before the program started.
  //Even if those two values change in the config file, we reset them to what they were before the program started.
  string password = queryMap[PASSWORD];
  string watchDir = queryMap[WATCH_DIR];
  string oldLogFile = queryMap[LOG_FILE];
  parseConfigFile();
  queryMap[PASSWORD] = password;
  queryMap[WATCH_DIR] = watchDir;
  string verboseVar = queryMap[VERBOSE];
  if(verboseVar.compare("true") == 0 || verboseVar.compare("True") == 0 || verboseVar.compare("TRUE") == 0){
    logRereadVerbose();
    loginotify();
  }
  else{
    logReread();
    loginotify();
  }
  string newLogFile = queryMap[LOG_FILE];
  if(oldLogFile.compare(newLogFile) != 0){
    closeLogFile();
    createLogFile();
    loginotify();
  }
    
}
