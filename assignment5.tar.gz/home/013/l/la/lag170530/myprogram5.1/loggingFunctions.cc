/*
 * Filename: loggingFunctions.cc
 * Date: 11/16/2020
 * Author: Luis Garcia
 * Email: lag170530@utdallas.edu
 * Course CS 3377.002 Fall 2020
 * Version 1.0 (or correct version)
 * Copyright 2020, All Rights Reserved
 *
 * Description
 *
 * This program will act as a series of functions that relate to logging information about the system in a log file.
 * This program includes methods that have to with creating a log file, closing the log file, and adding any addtional information 
 * in the logfile/stdout. Most logging functions have two versions where one is used if verbose = true or if verbose = false.
 * The top two methods will be used to create and close a log file as specified by the queryMap[LOG_FILE] value.
 * The first four printing methods actually prints to stdout and then after the log file is open/created, the methods afterwards 
 * only print to logfile. 
 */

 #include "program5.h"

using namespace std;

ofstream logfile;

//Called to create a log file that the daemon will write into.
void createLogFile(){
  string log = queryMap[LOG_FILE];
  logfile.open(log.c_str(), ios::out);
  logfile << "LOG FILE FOR PROGRAM : " << endl;
}

//Called when daemon is exited to close the file
void closeLogFile(){
  logfile << "Log file closed" << endl;
  logTerminateProgram();
  logfile.close();
}

//Below methods write to stdout. Used only in the beginning of the process.
//Write the steps happening at startup. Verbose = true
void startupMessageVerbose(){
  cout << "Parsing Command Line..." << endl;
  cout << "Values found in Command Line: " << endl;
  cout << "Daemon process enabled (T/F): "<< queryMap[DAEMON_PROCESS] << endl;
  cout << "Configuration File found: " << queryMap[CONFIG_FILE] << endl;
  cout << "Parsing Configuration File..." << endl;
}

//Write the steps happening at startup. Verbose = false
void startupMessage(){
  cout << "Parsing Command Line..." << endl;
  cout << "Parsing Config File..." << endl;
}

//Write the log file message. Verbose = true
void logfileMessageVerbose(){
  cout << "Values found in Configuration File: " << endl;
  cout << "Verbose messages enabled (T/F): " << queryMap[VERBOSE];
  cout << "Log file found: " << queryMap[LOG_FILE] << endl;
  cout << "Password found: " << queryMap[PASSWORD] << endl;
  cout << "Number of versions allowed: " << queryMap[NUM_VERSIONS] << endl;
  cout << "Watch Directory found: " << queryMap[WATCH_DIR] << endl;
  cout << "Log file (" << queryMap[LOG_FILE] << ") opened. All further information will be logged in the provided log file." << endl;
}

//Write the log file message. Verbose = false
void logfileMessage(){
  cout << "Log file opened. All further information will be logged in the provided log file." << endl;
}

//Below methods only write to the log file.
//Write if daemon mode is on.
void logDaemon(){
  logfile << "Daemon mode activiated." << endl;
  logfile << "Parent process exited." << endl;
  logfile << endl;
}

//Write that inotify is watching. 
void loginotify(){
  logfile << "inotify is watching..." << endl;
}

//Write the file that has been modified into the log file. Verbose = true
void logFileChangeVerbose(string change){
  logfile << "inotify has detected a modification of file " << change << "." << endl;
  logfile << "File " << change <<  " has been modified." << endl;
}

//Write the file that has been modified into the log file. Verbose = false
void logFileChange(){
  logfile << "A file has been modified." << endl;
 
}

//Write the file copy made into the log file. Verbose = true
void logFileCopyVerbose(string copy){
  logfile << "File copy " << copy << "has been created and added to the .versions subfolder." << endl;
  logfile << "Any changed files will be stored in the .versions of the directory " << queryMap[WATCH_DIR] << endl;
  logfile << endl;
}

//Write the file copy made into the log file. Verbose = false
void logFileCopy(){
  logfile << "A file copy has been created." << endl;
  logfile << endl;
}

//Prints when SIGINT is caught
void logSIGINT(int signum){
  logfile << "Interrupt signal (" << signum << ") received." << endl;
}

//Prints when SIGTERM is caught
void logSIGTERM(int signum){
  logfile << "Termination signal (" << signum << ") received." << endl;
}

//Prints when SIGHUP is caught
void logSIGHUP(int signum){
  logfile << "Reread signal (" << signum << ") received." << endl;
}

//Prints when SIGNUP is caught and Verbose = true
void logRereadVerbose(){
  logfile << "Reconfiguring system with new settings..." << endl;
  logfile << "Values found in Configuration File: " << endl;
  logfile << "Verbose messages enabled (T/F): " << queryMap[VERBOSE] << endl;
  logfile << "Log file found: " << queryMap[LOG_FILE] << endl;
  logfile << "Password found: " << queryMap[PASSWORD] << endl;
  logfile << "Number of versions allowed: " << queryMap[NUM_VERSIONS] << endl;
  logfile << "Watch Directory found: " << queryMap[WATCH_DIR] << endl;
  logfile << "Reread complete." << endl;
  logfile << endl;
}

//Prints when SIGNUP is caught and Verbose = false
void logReread(){
  logfile << "Reconfiguring system with new settings..." << endl;
  logfile << "Reread complete." << endl;
  logfile << endl;
}

//Prints when PID file is created at startup
void logCreatePID(){
  logfile << "Created PID file." << endl;
}

//Prints the PID in the log file
void logPrintPID(){
  logfile << "Process ID: " << getpid() << endl;
}

//Prints when the PID file is deleted
void logDeletePID(){
  logfile  << "Deleted PID file." << endl;
}

//Prints when the .versions folder is created
void logCreateSubfolder(){
  logfile << "Created .versions folder." << endl;
}

//Prints when the file catches a signal or gets a fatal error
void logTerminateProgram(){
  logfile << "Program terminated." << endl;
}
