/*
 * Filename: parseConfigFile.cc
 * Date: 11/16/20
 * Author: Luis Garcia
 * Email: lag170530@utdallas.edu
 * Course: CS 3377.002 Fall 2020
 * Version 1.0 (or correct version)
 * Copyright 2020, All Rights Reserved
 *
 * Description
 * The purpose of this program is to read and parse a config file either given by the user or given by the default of cs3377dirmond.conf.
 * This program uses rudeconfig (third party software) in order to parse the given file and the values from conf are stored in the
 * global map called queryMap to be used in other parts of the code.
 */

 #include "program5.h"

using namespace std;
using namespace rude;

int parseConfigFile(){
  //Create a Config object
  Config config;

  //Load the config file listed in queryMap[CONFIG] from parseCommandLine.cc
  //Check if file exists. Else error out
  string filename = queryMap[CONFIG_FILE];
  if(config.load(filename.c_str())){

    //Check if parameters section is in config file. Else error out
    if(config.setSection("Parameters", false)){

      if(config.exists("Verbose") && config.exists("LogFile") && config.exists("Password") && config.exists("NumVersions") && config.exists("WatchDir")){
	queryMap[VERBOSE] = config.getStringValue("Verbose");
	queryMap[LOG_FILE] = config.getStringValue("LogFile");
	queryMap[PASSWORD] = config.getStringValue("Password");
	queryMap[NUM_VERSIONS] = config.getStringValue("NumVersions");
	queryMap[WATCH_DIR] = config.getStringValue("WatchDir");
	return 0;

      }
      else{
	cout << "Error: Missing definitions in conf file" << endl;
        exit(0);
      }


    }
    else{
      cout << "Error: Missing parameters section in conf file" << endl;
      exit(0);
    }


  }

  else{
    cout << "Error: Missing conf file " << endl;
    exit(0);

  }

  return 0;
}




