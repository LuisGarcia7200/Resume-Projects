/*
 * Filename: parseCommandLine.cc
 * Date: 11/16/2020
 * Author: Luis Garcia
 * Email: lag170530@utdallas.edu
 * Course CS 3377.002 Fall 2020
 * Version 1.0 (or correct version)
 * Copyright 2020, All Rights Reserved
 *
 * Description
 *
 * This program will parse the command line and have two possible options outlined. The user can either include or not include a flag with daemon.
 * If flag for daemon is present on command line, then it saves the string true to the corresponding map element. Else, it saves false to the corresponding map element.
 * This program has the option of including a conf file and will be saved in corresponding map element. If the file is not present on the command line, then the default
 * value is saved in the corresponding map element.
 */

#include "program5.h"

using namespace std;

int parseCommandLine(int argc, char *argv[]){

  //TCLAP section
  //Create the cmdline object
  TCLAP::CmdLine cmd("CS 3377.002 Program 5", ' ', "1.0");

  //Daemon mode SwitchArg (optional)
  TCLAP::SwitchArg daemonMode("d","daemon", "Run in daemon mode (forks to run as a daemon)", cmd, false);

  //Config file UnlabeledValueArg (optional)
  TCLAP::UnlabeledValueArg<std::string> configFile("configFile", "The name of the configuration file. Defaults to cs3377dirmond.conf", false, "cs3377dirmond.conf", "configuration file name", false);

  //Add outfileArg and infileArg to cmd
  cmd.add(configFile);

  //Parse the line
  cmd.parse(argc, argv);
 
  //Set the default of daemon to false.
  queryMap[DAEMON_PROCESS] = "false";

  //If flag is present, set daemon key to true.
  if(daemonMode.getValue() == true){
     queryMap[DAEMON_PROCESS] = "true";
  }

  //Sets the value as either the inputted string or default string for the file names
  queryMap[CONFIG_FILE] = configFile.getValue();
  
  return 0;

}
