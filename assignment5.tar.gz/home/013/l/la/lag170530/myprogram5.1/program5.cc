/*
 * Filename: program5.cc
 * Date: 11/16/2020
 * Author: Luis Garcia
 * Email: lag170530@utdallas.edu
 * Course CS 3377.002 Fall 2020
 * Version 1.0 (or correct version)
 * Copyright 2020, All Rights Reserved
 *
 * Description
 *
 * The program is the only one with the main function and calls the global map once so that all linked files have access to the map. The main function will primarily call other methods 
 * and check if verbose is enabled for the logging functions. The order is as follows: parse command line, parse config file, check if you run as a daemon, 
 * create log file, create and check for pid file, create .versions subfolder in watchdir, enable signalhandling methods for SIGINT, SIGTERM, and SIGHUP, and use an infinite loop to continously
 * watch the watchdir using inotify.
 */


#include "program5.h"

using namespace std;

std::map<int,std::string> queryMap;

int main(int argc, char *argv[]){

  cout << "Starting Program..." << endl;
  
  //Parse Command Line
  parseCommandLine(argc, argv);
    
  //Parse Config File
  parseConfigFile();
   
  if(checkPIDFileExistence() == true){
    cout << "PID File exists." << endl;
    cout << "Program terminated." << endl;
    return 0;
  }
  else{
    /* do nothing and continue down program*/
  }

  string verboseVar = queryMap[VERBOSE];  
  if(verboseVar.compare("true") == 0 || verboseVar.compare("True") == 0 || verboseVar.compare("TRUE") == 0){
    startupMessageVerbose();
  }
  else{
    startupMessage();
  }
  
  if(verboseVar.compare("true") == 0 || verboseVar.compare("True") == 0 || verboseVar.compare("TRUE") == 0){
    logfileMessageVerbose();
  }
  else{
    logfileMessage();
  }
   
  //Check if daemon mode is enabled.
  daemonOperation();

  //Create log file
  createLogFile();
  
  //Create PID file
  bool pidFile = createPID();
  if(pidFile == false){
    perror("PID exists");
    exit(1);
  }

  //Create .versions subfolder
  createSubfolder();
    
  //Set signal handlers
  signal(SIGINT, signalHandling1);
  signal(SIGTERM, signalHandling2);
  signal(SIGHUP, signalHandling3);

  //Infinite loop that will watch the folder using inotify  
  while(1){
    inotifyFunction();
  }
  return 0;
  
}//end of method
