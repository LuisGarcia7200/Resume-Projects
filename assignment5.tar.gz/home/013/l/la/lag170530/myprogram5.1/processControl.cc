/*
 * Filename: processControl.cc
 * Date: 11/16/20
 * Author: Luis Garcia
 * Email: lag170530@utdallas.edu
 * Course: CS 3377.002 Fall 2020
 * Version 1.0 (or correct version)
 * Copyright 2020, All Rights Reserved
 *
 * Description
 * This program deals with enabling the daemon mode, creating and deleting a PID file, creating the subfolder .versions, and exiting the program. In order to enable daemon mode,
 * the user must have included -d flag in the command line and then it will use fork(). After using fork(), the parent process will exit and the program continues. With the PID file, 
 * it creates one and prints the process id to it. When the program is terminated, the PID file will be closed and then deleted. With the .versions subfolder, it will try to create one 
 * if one doesn't exist and will use the existing one if one currently exists. Concering the exit program, it will call the methods of deletePID and closeLogFile and then exit the program.
 */

 #include "program5.h"

using namespace std;

ofstream outfile;
string out = "cs3377dirmond.pid";

//Check if daemon mode is enabled.
//If enabled, call fork and parent exits. Child continues.
//If not enabled, just continue.
void daemonOperation(){
  string daemonVar = queryMap[DAEMON_PROCESS];
  string verboseVar = queryMap[VERBOSE];
  if(daemonVar.compare("true") == 0){
    pid_t forkvalue = 0;
    forkvalue = fork();
    if(forkvalue == -1){
      perror("Error in fork. No child createed");
    }
    else if(forkvalue != 0){
      if(verboseVar.compare("true") == 0 || verboseVar.compare("True") == 0 || verboseVar.compare("TRUE") == 0){
        logDaemon();
        exit(0);        
      }
        exit(0);
    
    }
    
  }

}

//Helper method for createPID() and checks if a PID exists at startup of program5
bool checkPIDFileExistence(){
  struct stat statbuf1;
  if(stat(out.c_str(), &statbuf1) == 0){
    return true; //file exists so exit
  }
   return false; //file doesn't exist so continue
}


//Check if PID File already exists. If it does return false.
//Else create PID File and write PID to it and return true.
bool createPID(){

  string verboseVar = queryMap[VERBOSE];
  if(checkPIDFileExistence() == true){
    return false;
  }
  else{
    //Write Process ID to PID File
    outfile.open(out.c_str(), ios::out);
    outfile  << getpid() << endl; 
    if(verboseVar.compare("true") == 0 || verboseVar.compare("True") == 0 || verboseVar.compare("TRUE") == 0){
      logCreatePID();
      logPrintPID();
      return true;
    }
    else{
      return true;
    }

  }  
 
}

//Close PID File
void deletePID(){
  string verboseVar = queryMap[VERBOSE];
  if(verboseVar.compare("true") == 0 || verboseVar.compare("True") == 0 || verboseVar.compare("TRUE") == 0){
  logDeletePID();
  }
  outfile.close();
  remove(out.c_str());
}

//Create .versions subfolder. Check if the directory exists, if it does use it.
//Else make one using the system command.
void createSubfolder(){
  struct stat statbuf2;
  string verboseVar = queryMap[VERBOSE];
  string subfolder = "/home/013/l/la/lag170530/testdir/.versions";
  if(stat(subfolder.c_str(), &statbuf2) != 0){
    int dir_err = system("mkdir /home/013/l/la/lag170530/testdir/.versions");
    if(dir_err  == -1){
      perror("Error creating folder");
    }
  }
  if(verboseVar.compare("true") == 0 || verboseVar.compare("True") == 0 || verboseVar.compare("TRUE") == 0){
    logCreateSubfolder();
  }
  
}

//Exit the program.
void exitProgram(){
  deletePID();
  closeLogFile();
  exit(0);
}
