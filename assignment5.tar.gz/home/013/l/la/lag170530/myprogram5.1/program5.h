#ifndef _PROGRAM_5_
#define _PROGRAM_5_

/*
 * Filename:program5.h
 * Date:11/3/2020
 * Author:Luis Garcia
 * Email:lag170530@utdallas.edu
 * Version:1.0
 * Copyright:2020, All Rights Reserved
 *
 * Description:
 * This is a header file that #includes the neccessary files and function prototypes for parse.y, scan.l, and program4.c.
 */


#include <string>
#include <fstream>
#include <iostream>
#include <map>
#include <unistd.h>

#include <tclap/CmdLine.h>
#include <tclap/SwitchArg.h>
#include <tclap/UnlabeledValueArg.h>
#include <tclap/CmdLineOutput.h>

#include <rude/config.h>

#include <csignal>

#include <sys/stat.h>
#include <sys/inotify.h>
#include <sys/types.h>
#include <limits.h>
#include <cstddef>

extern std::map<int, std::string> queryMap;
typedef enum {DAEMON_PROCESS=1, CONFIG_FILE, VERBOSE, LOG_FILE, PASSWORD, NUM_VERSIONS, WATCH_DIR}queries;

int parseCommandLine(int argc, char *argv[]);

int parseConfigFile();

void signalHandling1(int signum);
void signalHandling2(int signum);
void signalHandling3(int signum);

void createLogFile();
void closeLogFile();
void startupMessageVerbose();
void startupMessage();
void logfileMessageVerbose();
void logfileMessage();
void logDaemon();
void loginotify();
void logFileChangeVerbose(std::string change);
void logFileChange();
void logFileCopyVerbose(std::string copy);
void logFileCopy();
void logSIGINT(int signum);
void logSIGTERM(int signum);
void logSIGHUP(int signum);
void logRereadVerbose();
void logReread();
void logCreatePID();
void logPrintPID();
void logDeletePID();
void logCreateSubfolder();
void logTerminateProgram();

void daemonOperation();
bool checkPIDFileExistence();
bool createPID();
void deletePID();
void createSubfolder();
void exitProgram();

void inotifyFunction();
std::string getTimeStamp();
void createCopy(std::string fileName);

#endif /* _PROGRAM_5_   */
