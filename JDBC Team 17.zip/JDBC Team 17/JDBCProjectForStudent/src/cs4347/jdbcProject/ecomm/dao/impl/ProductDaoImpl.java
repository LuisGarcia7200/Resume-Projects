/* NOTICE: All materials provided by this project, and materials derived 
 * from the project, are the property of the University of Texas. 
 * Project materials, or those derived from the materials, cannot be placed 
 * into publicly accessible locations on the web. Project materials cannot 
 * be shared with other project teams. Making project materials publicly 
 * accessible, or sharing with other project teams will result in the 
 * failure of the team responsible and any team that uses the shared materials. 
 * Sharing project materials or using shared materials will also result 
 * in the reporting of every team member to the Provost Office for academic 
 * dishonesty. 
 */ 



package cs4347.jdbcProject.ecomm.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.sql.Statement;
import java.sql.ResultSet;
import cs4347.jdbcProject.ecomm.dao.ProductDAO;
import cs4347.jdbcProject.ecomm.entity.Product;
import cs4347.jdbcProject.ecomm.util.DAOException;

/*
 * ProductDAO Implementation
 * NAME: Eric Ikeda
 * CLASS: CS 4347.002
 * NETID: eai170000
 * GROUP: 17
 * DATE: 4/4/2021
 */

public class ProductDaoImpl implements ProductDAO
{
	private static final String insertSQL = "INSERT INTO product (prod_name, prod_desc, prod_category, prod_upc) VALUES(?, ?, ?, ?);";
		    
    private static final String selectSQL = "SELECT id, prod_name, prod_desc, prod_category, prod_upc FROM product WHERE id = ?;";
		    
	private static final String updateSQL = "UPDATE product SET prod_name = ?, prod_desc = ?, prod_category = ?, prod_upc = ? WHERE id = ?;";
		    
	private static final String deleteSQL = "DELETE FROM product WHERE id = ?;";
		    
	private static final String selectByCategorySQL = "SELECT id, prod_name, prod_desc, prod_category, prod_upc FROM product WHERE prod_category = ?;";
		    
	private static final String selectBYUPCSQL = "SELECT id, prod_name, prod_desc, prod_category, prod_upc FROM product WHERE prod_upc = ?;";
    
	@Override
	//Create a Product Object associated with the inputed Product. 
    //Throw DAOException when given a NON-NULL Product ID. 
    //Returns Product with the ID attribute assigned the key value provided by the auto-increment primary key column.
    public Product create(Connection connection, Product product) throws SQLException, DAOException
    {
		//Throw DAOException when given a NON-NULL Product ID. 
    	if(product.getId() != null) {
    		throw new DAOException("Error. Trying to insert Product with NON-NULL Product ID");
    	}
    	
    	PreparedStatement ps = null;
    	try {
    		ps = connection.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS);
    		ps.setString(1, product.getProdName());
    		ps.setString(2, product.getProdDescription());
    		ps.setInt(3, product.getProdCategory());
    		ps.setString(4, product.getProdUPC());
    		ps.executeUpdate();
    		
    		//Copy the SQL generated auto-increment key to the Product ID.
			ResultSet keyRS = ps.getGeneratedKeys();
			//set ID to the correct ID.
			if(keyRS.next())
			{
				int lastKey = keyRS.getInt(1);
				product.setId((long) lastKey);
			}
			else
			{
				throw new SQLException("Error. Could not generate auto-increment key");
			}
    		
    		return product;
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
    }

    @Override
    //Retrieve a Product Object associated with the inputed Product ID.
    //Throw DAOException if given a NULL Product ID
    //Return NULL if retrieving a non-existent Product ID.
    public Product retrieve(Connection connection, Long id) throws SQLException, DAOException
    {
    	//Throw DAOException if given a NULL ID
    	if (id == null) {
    		throw new DAOException("Error. Trying to retrieve Product with NULL Product ID");
        }

        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(selectSQL);
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            //Return NULL if retrieving a non-existent Product ID.
            if (!rs.next()) {
                return null;
            }

            Product product = new Product();
            product.setId(rs.getLong("id"));
            product.setProdName(rs.getString("prod_name"));
            product.setProdDescription(rs.getString("prod_desc"));
            product.setProdCategory(rs.getInt("prod_category"));
            product.setProdUPC(rs.getString("prod_upc"));
            return product;
        }
        finally {
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
        }
    }

    @Override
    //Update the inputed Product Object.
  	//Throw DAOException when given a Product Object with a NULL Product ID.
    public int update(Connection connection, Product product) throws SQLException, DAOException
    {
    	//Throw DAOException when given a Product Object with a NULL Product ID.
    	if(product.getId() == null) {
     	   throw new DAOException("Error. Trying to update Product with NULL Product ID");
        }
        
        PreparedStatement ps = null;
        try {
     	   ps = connection.prepareStatement(updateSQL);
     	   ps.setString(1, product.getProdName());
     	   ps.setString(2, product.getProdDescription());
     	   ps.setInt(3, product.getProdCategory());
     	   ps.setString(4, product.getProdUPC());
     	   ps.setLong(5, product.getId());
     	   int rows = ps.executeUpdate();
     	   return rows;
        }
        finally {
     	   if(ps != null && !ps.isClosed()) {
     		  ps.close(); 
     	   }
        }
        
    }

    @Override
    //Delete a Product Object associated with the inputed Product ID.
    //Throw DAOException when given a NULL Product ID.
    public int delete(Connection connection, Long id) throws SQLException, DAOException
    {
    	//Throw DAOException when given a NULL Product ID.
    	if (id == null) {
            throw new DAOException("Error. Trying to delete Product with NULL Product ID");
        }

        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(deleteSQL);
            ps.setLong(1, id);
            int rows = 0;
            rows = ps.executeUpdate();
            return rows;
        }
        finally {
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
        }
    	
    }

    @Override
    //Retrieve a List of Product Objects associated with the inputed Category.
    public List<Product> retrieveByCategory(Connection connection, int category) throws SQLException, DAOException
    {
    	PreparedStatement ps = null;
    	try{
    		ps = connection.prepareStatement(selectByCategorySQL);
    		ps.setLong(1, category);
    		ResultSet rs = ps.executeQuery();
    		List<Product> result = new ArrayList<Product>();
    		while(rs.next()) {
    			Product prod = new Product();
    			prod.setId(rs.getLong("id"));
                prod.setProdName(rs.getString("prod_name"));
                prod.setProdDescription(rs.getString("prod_desc"));
                prod.setProdCategory(rs.getInt("prod_category"));
                prod.setProdUPC(rs.getString("prod_upc"));
            	result.add(prod);
    		}
            
    		 return result;
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
    }

    @Override
    //Retrieve a Product with a specific UPC. 
    //Throw DAOException if given a NULL UPC.
    //Return null if retrieving a non-existent Product ID.
    //The UPC is unique to each product, per the description in the ProductDao.java Interface, so this returns one Product.
    public Product retrieveByUPC(Connection connection, String upc) throws SQLException, DAOException
    {
    	//Throw DAOException if given a NULL UPC.
    	if (upc == null) {
            throw new DAOException("Error. Trying to retrieve Product with NULL UPC");
        }

        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(selectBYUPCSQL);
            ps.setString(1, upc);
            ResultSet rs = ps.executeQuery();
            //Return null if retrieving a non-existent Product ID.
            if (!rs.next()) {
                return null;
            }
            Product product = new Product();
            product.setId(rs.getLong("id"));
            product.setProdName(rs.getString("prod_name"));
            product.setProdDescription(rs.getString("prod_desc"));
            product.setProdCategory(rs.getInt("prod_category"));
            product.setProdUPC(rs.getString("prod_upc"));
            return product;
        }
        finally {
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
        }
    }

}
