/* NOTICE: All materials provided by this project, and materials derived 
 * from the project, are the property of the University of Texas. 
 * Project materials, or those derived from the materials, cannot be placed 
 * into publicly accessible locations on the web. Project materials cannot 
 * be shared with other project teams. Making project materials publicly 
 * accessible, or sharing with other project teams will result in the 
 * failure of the team responsible and any team that uses the shared materials. 
 * Sharing project materials or using shared materials will also result 
 * in the reporting of every team member to the Provost Office for academic 
 * dishonesty. 
 */ 



package cs4347.jdbcProject.ecomm.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import cs4347.jdbcProject.ecomm.dao.AddressDAO;
import cs4347.jdbcProject.ecomm.entity.Address;
import cs4347.jdbcProject.ecomm.util.DAOException;

/*
 * AddressDAO Implementation
 * NAME: Zachary Gray
 * CLASS: CS 4347.002
 * NETID: zsg170000
 * GROUP: 17
 * DATE: 4/4/2021
 */

public class AddressDaoImpl implements AddressDAO
{
	
	private static final String insertSQL = "INSERT INTO address (address1, address2, city, state, zipcode, CUSTOMER_id) VALUES (?, ?, ?, ?, ?, ?);";
	         
	private static final String selectSQL = "SELECT address1, address2, city, state, zipcode FROM address WHERE CUSTOMER_id = ?;";
		    
	private static final String deleteSQL = "DELETE FROM address WHERE CUSTOMER_id = ?;";
	
    @Override
    //Create an Address Object associated with the inputed Customer ID. 
    //Throw DAOException when given a NULL id. 
    public Address create(Connection connection, Address address, Long customerID) throws SQLException, DAOException
    {
    	//Throw DAOException when given a NULL Customer ID.
    	if(customerID == null) {
    		throw new DAOException("Error. Trying to insert Address with NULL Customer ID");
    	}
    	
    	PreparedStatement ps = null;
    	try {
    		ps = connection.prepareStatement(insertSQL);
    		ps.setString(1, address.getAddress1());
    		ps.setString(2, address.getAddress2());
    		ps.setString(3, address.getCity());
    		ps.setString(4, address.getState());
    		ps.setString(5,  address.getZipcode());
    		ps.setLong(6, customerID);
    	    int res = ps.executeUpdate();
    		if(res != 1) {
    			throw new DAOException("Error. Create did not execute the correct amount of rows.");
    		}
    		return address;
    	}
    	
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
    	
    }

    @Override
    //Retrieve an Address Object associated with the inputed Customer ID.
    //Throw DAOException when given a NULL Customer ID.
    //Return NULL if retrieving a non-existent Customer ID.
    public Address retrieveForCustomerID(Connection connection, Long customerID) throws SQLException, DAOException
    {
    	
    	//Throw DAOException when given a NULL Customer ID.
    	if (customerID == null) {
    		throw new DAOException("Error. Trying to retrieve Address with NULL Customer ID");
		}
    	
    	PreparedStatement ps = null;
    	try{
    		ps = connection.prepareStatement(selectSQL);
    		ps.setLong(1, customerID);
    		ResultSet rs = ps.executeQuery();
    		//Return NULL if retrieving a non-existent ID.
    		if(!rs.next()) {
    			return null;
    		}
    		
    		Address address = new Address();
    		address.setAddress1(rs.getString("address1"));
    		address.setAddress2(rs.getString("address2"));
    		address.setCity(rs.getString("city"));
    		address.setState(rs.getString("state"));
    		address.setZipcode(rs.getString("zipcode"));
    		return address;
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
    }

    @Override
    //Delete an Address Object associated with the inputed Customer ID.
    //Throw a DAOException when given a NULL Customer ID.
    public void deleteForCustomerID(Connection connection, Long customerID) throws SQLException, DAOException
    {
    	//Throw DAOException when given a NULL Customer ID.
    	if(customerID == null) {
    		throw new DAOException("Error. Trying to delete Address with NULL Customer ID.");
    	}
    	PreparedStatement ps = null;
    	try {
    		ps = connection.prepareCall(deleteSQL);
    		ps.setLong(1, customerID);
    		ps.executeUpdate();
    	}
    	finally {
    		if(ps != null && !ps.isClosed()) {
    			ps.close();
    		}
    	}
    	
        
    }

}
