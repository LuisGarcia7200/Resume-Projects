#include "osprog2.h"
using namespace std;

//Semaphores
sem_t max_capacity;
sem_t patient_at_desk;

//Semaphore Arrays. Size of doctors/nurses.
sem_t nurseSemaphore[MAX_DOC_THREADS];
sem_t doctorSemaphore[MAX_DOC_THREADS];

//Semaphore Arrays. Size of patients.
sem_t patientSemaphore[MAX_PATIENTS_THREADS];
sem_t register_complete[MAX_PATIENTS_THREADS];
sem_t patient_in_waiting_room[MAX_PATIENTS_THREADS];
sem_t tell_doctor_symptoms[MAX_PATIENTS_THREADS];
sem_t doctor_advice[MAX_PATIENTS_THREADS];
sem_t finishedNurse[MAX_PATIENTS_THREADS];
sem_t finishedDoc[MAX_PATIENTS_THREADS];

//Mutual Exclusion Semaphores.
sem_t mutex_1;
sem_t mutex_2;
sem_t mutex_3[MAX_PATIENTS_THREADS];
sem_t mutex_4[MAX_PATIENTS_THREADS];

//Queues. 1 for patients. 3 for each doctor. 1 for keeping track of which threads exit.
queue<int> patientQ;
queue<int> doctorQ0;
queue<int> doctorQ1;
queue<int> doctorQ2;
queue<int> finishedQ;

//HashMap for mapping patients to doctors.
map <int, int> patientToDoc;

//Command Line Parameter variables.
int docNum = 0;
int patNum = 0;

int main(int argc, char* argv[]){

  //Set seed for random number generator.
  srand(time(NULL));

  //Save command line parameters.
  docNum = atoi(argv[1]);
  patNum = atoi(argv[2]);

  //Check if command line parameters are allowed.
  if(docNum < 1 || docNum > MAX_DOC_THREADS || patNum < 1 || patNum > MAX_PATIENTS_THREADS){
    printf ("%s \n", "Error. Incorrect Parameters Entered for Doctor/Patient amount. Terminated Program.");
    exit(1);
  }

  //Initialize Semaphores,
  sem_init(&max_capacity, 0, patNum);
  sem_init(&patient_at_desk, 0, 0);

  //Initialize Array Semaphores of size equal to doctors/nurses,
  for(int i = 0; i < docNum; i ++){
    sem_init(&nurseSemaphore[i], 0, 0);
    sem_init(&doctorSemaphore[i], 0, 0);
    sem_init(&mutex_3[i], 0, 1);
    sem_init(&mutex_4[i], 0, 1);
  }

  //Initialize Array Semaphores of size equal to patients.
  for(int j = 0; j < patNum; j++){
    sem_init(&patientSemaphore[j], 0, 0);
    sem_init(&register_complete[j], 0, 0);
    sem_init(&patient_in_waiting_room[j], 0, 0);
    sem_init(&tell_doctor_symptoms[j], 0, 0);
    sem_init(&doctor_advice[j], 0, 0);
    sem_init(&finishedNurse[j], 0, 0);
    sem_init(&finishedDoc[j], 0, 0);
  }

  //Initialize Mutual Exclusion Semaphores.
  sem_init(&mutex_1, 0, 1);
  sem_init(&mutex_2, 0, 1);

  //Create Pthreads.
  pthread_t doctorThread[docNum];
  pthread_t nurseThread[docNum];
  pthread_t patientThread[patNum];
  pthread_t receptionistThread;

  //Create ID array for threads
  int docAndNurseID[docNum];
  int patID[patNum];

  //Initialize Pthreads
  //Doctor and Nurse Threads
  for(int i = 0; i < docNum; i++){
    docAndNurseID[i] = i;
    pthread_create(&doctorThread[i], NULL, doctor, &docAndNurseID[i]);
    pthread_create(&nurseThread[i], NULL, nurse, &docAndNurseID[i]);
  }

  //Receptionist Thread
  pthread_create(&receptionistThread, NULL, receptionist, NULL);

  //Patient Threads.
  for(int j = 0; j < patNum; j++){
    patID[j] = j;
    pthread_create(&patientThread[j], NULL, patient, &patID[j]);
  }

  //While loop that loops until finishedQ is equal to the number of patient threads.
  //finishedQ is a queue that keep track of which threads have ended.
  //Everytime a thread ends, it pushes it's ID to finishedQ.
  //So when every thread up to patient number has exited, main method exits by returning 0.
  while(finishedQ.size() < patNum){
    //do nothing
  }

  return 0;

}


//Thread Methods
//Patient Method
void* patient(void* patientArg){
  //Register Patients one at a time.
  int patientID = *(int *) patientArg;           //Save the patientID. PatientID is unique integer ranging from 0 to patient command line parameter.
  patientToDoc[patientID] = randDoc(docNum);     //Set HashMap. Patient ID is key and the doctor the patient is assigned to is the value. Doctor is randomly assigned.
  sem_wait(&max_capacity);                       //Check Max capacity. Allows only 30 patients.
  //Mutual Exclusion 1: Register only one patient at time. Interacts solely with Receptionist Thread.
  sem_wait(&mutex_1);                            //Check for mutual exclusion 1 semaphore.
  enqueueP(patientID);                           //Add to patient queue.
  enter_waiting_room(patientID);                 //Print enter waiting room.
  sem_post(&patient_at_desk);                    //Signal to receptionist that patient is at the desk.
  sem_wait(&register_complete[patientID]);       //Wait for the receptionist to signal that registration is complete for this specific patient thread.
  sit_in_waiting_room(patientID);                //Print sitting in waiting room.
  sem_post(&patient_in_waiting_room[patientID]); //Signal to receptionist that specific patient is sitting in waiting room.
  sem_post(&mutex_1);                            //End mutual exclusion 1. Allows another patient thread to enter waiting room and get registered.

  //Interact with Doctor and Nurse Threads.
  sem_wait(&patientSemaphore[patientID]);                 //Wait for the nurse to call this specific patient thread.
  enter_doctor_office(patientID, patientToDoc[patientID]);//Print enter doctor office.
  sem_post(&tell_doctor_symptoms[patientID]);             //Signal to doctor that this thread has told the doctor their symptoms.
  sem_wait(&doctor_advice[patientID]);                    //Wait for advice from the doctor.
  receive_advice(patientID, patientToDoc[patientID]);     //Print recieve advice.
  leave_office(patientID);                                //Print leave office.
  sem_post(&finishedDoc[patientID]);                      //Signal to doctor that you are finished. Frees Doctor for next patient.
  sem_post(&finishedNurse[patientID]);                    //Signal to nurse that you are finished. Frees Nurse for next patient.
  sem_post(&max_capacity);                                //Signal Max Capacity.
  finishedQ.push(patientID);                              //Push patientID to finishedQ. Increases size of finishedQ by 1.
  pthread_exit(NULL);                                     //Exit Patient Thread.
}


void* receptionist(void* recArg){
  //recArg is NULL so no need to save the argument
  int patientID = 0;
  int nurseID = 0;
  while(true){                                     //Infinite Loop. Ends when main method exits.
    sem_wait(&patient_at_desk);                    //Wait until any patient is at desk
    sem_wait(&mutex_2);                            //Mutual exclusion 2. Register only patient at a time. Create Patient to Doc relationship here.
    patientID = dequeueP();                        //Dequeue P to ensure that you are serving the patient who has been there the longest.
    nurseID = patientToDoc[patientID];             //Find Nurse ID and Doc ID that the patient will see from hashmap.
    if(nurseID == 0){                              //Queue patient for their specific nurse/doctor.
      enqueuePatAtDoc0(patientID);
    }
    else if(nurseID == 1){
      enqueuePatAtDoc1(patientID);
    }
    else{
      enqueuePatAtDoc2(patientID);
    }
    register_patient(patientID);                   //Print that the patient has been registered.
    sem_post(&register_complete[patientID]);       //Signal to specific patient that they have been registered successfully.
    sem_wait(&patient_in_waiting_room[patientID]); //Wait from specific patient that they are ready to be seen by their nurse/doctor.
    sem_post(&nurseSemaphore[nurseID]);            //Signal to specific nurse that the patient is ready.
    sem_post(&mutex_2);                            //End mutual exclusion 2. Allow a new patient to be registered by receptionist.
  }
}

void* nurse(void* nurseArg){
  int nurseID = *(int *) nurseArg;
  int patientID = 0;
  while(true){                               //Infinite Loop. Ends when main method exits.
    sem_wait(&nurseSemaphore[nurseID]);      //Wait for this specific nurse to be called by receptionist.
    sem_wait(&mutex_3[nurseID]);             //Mutual Exclusion 3. Ensures that only one nurse thread with this specific ID may service at a patient. Can run concurrently with nurses with different IDs.
    if(nurseID == 0){                        //Find the patient at top of the nurse/doctor queue that corresponds with nurse ID
      patientID = getPatAtTopOfDoc0();
    }
    else if(nurseID == 1){
      patientID = getPatAtTopOfDoc1();
    }
    else{
      patientID = getPatAtTopOfDoc2();
    }
    take_to_doctor_office(nurseID, patientID);//Print nurse takes patient to doctor's office
    sem_post(&doctorSemaphore[nurseID]);      //Signal Doctor with same ID as nurse
    sem_post(&patientSemaphore[patientID]);   //Signal specific patient that they may continue.
    sem_wait(&finishedNurse[patientID]);      //Wait until patient is finishes execution and leaves.
    sem_post(&mutex_3[nurseID]);              //End mutual exclusion 3 for this specific nurse thread so it may service a new patient.
  }

}

void* doctor(void* docArg){
  int doctorID = *(int *) docArg;
  int patientID = 0;
  while(true){                                 //Infinite Loop. Ends when main method exits.
    sem_wait(&doctorSemaphore[doctorID]);      //Waits for this specific doctor to be called by nurse with same ID.
    sem_wait(&mutex_4[doctorID]);              //Mutual Exclusion 4. Ensures only one doctor thread with this same ID can continue execution. Can run concurrently with doctors with different IDs.
    if(doctorID == 0){                         //Find the patient at top of the nurse/doctor queue that corresponds with doctor ID and pop them from queue.
      patientID = dequeuePatAtDoc0();
    }
    else if(doctorID == 1){
      patientID = dequeuePatAtDoc1();
    }
    else{
      patientID = dequeuePatAtDoc2();
    }
    sem_wait(&tell_doctor_symptoms[patientID]);//Wait for that specific patient to tell this doctor their symptoms.
    listen_to_patient(doctorID, patientID);    //Print listen to patient.
    sem_post(&doctor_advice[patientID]);       //Signal to specific patient that doctor has given them advice
    sem_wait(&finishedDoc[patientID]);         //Wait until patient is finishes execution and leaves.
    sem_post(&mutex_4[doctorID]);              //End mutual exclusion 4 for this specific doctor thread so it may service a new patient.
  }
}

//Math Method
//Returns random Integer from 0 to docNumber.
//If 3, returns 0,1, or 2.
//If 2, returns 0,1
//If 1, returns 0
int randDoc(int docNumber){
  int randomNum = rand() % docNumber;
  return randomNum;
}

//Queue Methods for Patients
void enqueueP(int patientID){
  patientQ.push(patientID);
}

int dequeueP(){
  int temp = patientQ.front();
  patientQ.pop();
  return temp;
}

//Queue Methods for Doctors 0-2
void enqueuePatAtDoc0(int patientID){
  doctorQ0.push(patientID);
}

int dequeuePatAtDoc0(){
  int temp = doctorQ0.front();
  doctorQ0.pop();
  return temp;
}

int getPatAtTopOfDoc0(){
  int temp = doctorQ0.front();
  return temp;
}

void enqueuePatAtDoc1(int patientID){
  doctorQ1.push(patientID);
}

int dequeuePatAtDoc1(){
  int temp = doctorQ1.front();
  doctorQ1.pop();
  return temp;
}

int getPatAtTopOfDoc1(){
  return doctorQ1.front();
}

void enqueuePatAtDoc2(int patientID){
  doctorQ2.push(patientID);
}

int dequeuePatAtDoc2(){
  int temp = doctorQ2.front();
  doctorQ2.pop();
  return temp;
}

int getPatAtTopOfDoc2(){
  return doctorQ2.front();
}

//Print Methods
void enter_waiting_room(int patientID){
  printf("%s %d %s \n", "Patient", patientID, "enters waiting room, waits for receptionist");
}

void register_patient(int patientID){
  printf("%s %d \n", "Receptionist registers patient", patientID);
}

void sit_in_waiting_room(int patientID){
  printf("%s %d %s \n", "Patient", patientID, "leaves receptionist and sits in waiting room");
}

void take_to_doctor_office(int nurseID, int patientID){
  printf("%s %d %s %d %s \n", "Nurse", nurseID, "takes patient", patientID, "to doctor's office");
}

void enter_doctor_office(int patientID, int doctorID){
  string doc = to_string(doctorID);
  doc = doc + "'s office";
  printf("%s %d %s %s \n", "Patient", patientID, "enter doctor", doc.c_str());
}

void listen_to_patient(int doctorID, int patientID){
  printf("%s %d %s %d \n", "Doctor", doctorID, "listens to symptoms from patient", patientID);
}

void receive_advice(int patientID, int doctorID){
  printf("%s %d %s %d \n", "Patient", patientID, "receives advice from doctor", doctorID);
}

void leave_office(int patientID){
  printf("%s %d %s \n", "Patient", patientID, "leaves");
}
