/*
 * Filename: osprog2.h
 * Date: 4/7/2021
 * Author: Luis Garcia
 * Email: lag170530@utdallas.edu
 * Course CS 4348.002 Spring 2021
 * Version 1.0 (or correct version)
 * Copyright 2020, All Rights Reserved
 *
 * Description
 *
 * This is a header file for osprog2.cc
 */

 #ifndef PROGRAM2_H
 #define PROGRAM2_H

#include <pthread.h>
#include <string>
#include <string.h>/* for strerror() */
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <iostream>
#include <semaphore.h>
#include <queue>
#include <map>

//Constants
#define MAX_DOC_THREADS 3
#define MAX_PATIENTS_THREADS 30

//Function prototypes
//Thread methods
void *doctor(void *docArg);
void *nurse(void *nurseArg);
void *receptionist(void *recArg);
void *patient(void *patientArg);
//Queue methods
void enqueueP(int patientID);
int dequeueP();
void enqueuePatAtDoc0(int patientID);
int dequeuePatAtDoc0();
int getPatAtTopOfDoc0();
void enqueuePatAtDoc1(int patientID);
int dequeuePatAtDoc1();
int getPatAtTopOfDoc1();
void enqueuePatAtDoc2(int patientID);
int dequeuePatAtDoc2();
int getPatAtTopOfDoc2();

//Print methods
void enter_waiting_room(int patientID);
void register_patient(int patientID);
void sit_in_waiting_room(int patientID);
void take_to_doctor_office(int nurseID, int patientID);
void enter_doctor_office(int patientID, int doctorID);
void listen_to_patient(int doctorID, int patientID);
void receive_advice(int patientID, int doctorID);
void leave_office(int patientID);

//Math methods
int randDoc(int docNumber);

 #endif
